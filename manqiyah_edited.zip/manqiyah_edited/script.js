/* ============================================================
   1. قاعدة بيانات محاكاة (بيانات المتقدمين المسترجعة)
   ============================================================ */
const mockDB = {
    "1000000001": { 
        name: "عبدالله بن علي الشهري", 
        uni: "جامعة الملك فهد للبترول والمعادن", 
        major: "هندسة برمجيات" 
    },
    "1000000002": { 
        name: "نورة بنت سعد القحطاني", 
        uni: "جامعة الأميرة نورة", 
        major: "أمن سيبراني" 
    },
    "1111111111": { 
        name: "خالد بن محمد العتيبي", 
        uni: "جامعة الملك سعود", 
        major: "إدارة أعمال" 
    },
    "default": { 
        name: "مستخدم جديد", 
        uni: "غير مسجل", 
        major: "غير مسجل" 
    }
};

/* ============================================================
   2. إدارة تسجيل الدخول والـ OTP (الرحلة الكاملة)
   ============================================================ */

// تبديل الواجهة بين متقدم وموظف
function toggleUserType() {
    const type = document.getElementById('userType').value;
    const applicantSection = document.getElementById('applicantFields');
    const employeeSection = document.getElementById('employeeFields');
    const errorDisplay = document.getElementById('loginError');

    errorDisplay.textContent = ""; // مسح الأخطاء عند التبديل

    if (type === 'applicant') {
        applicantSection.classList.remove('hidden');
        employeeSection.classList.add('hidden');
    } else {
        applicantSection.classList.add('hidden');
        employeeSection.classList.remove('hidden');
    }
}

// الخطوة 1: إرسال الرمز وإخفاء الخيارات (التعديل المطلوب)
function handleSendOtp() {
    const idInput = document.getElementById('loginId').value;
    const errorDisplay = document.getElementById('loginError');

    if (idInput.length === 10) {
        // --- التفاصيل المهمة: إخفاء العناصر لتركيز المستخدم ---
        document.getElementById('userTypeContainer').classList.add('hidden'); // إخفاء نوع المستخدم
        document.getElementById('idStep').classList.add('hidden');           // إخفاء حقل الهوية والزر
        
        // إظهار حقل الـ OTP
        document.getElementById('otpSection').classList.remove('hidden');
        errorDisplay.textContent = "";
    } else {
        errorDisplay.textContent = "يرجى إدخال رقم هوية صحيح مكون من 10 أرقام";
    }
}

// الخطوة 2: معالجة الرمز وجلب بيانات المتقدم للمراجعة
function processOtp() {
    const otp = document.getElementById('otpCode').value;
    const id = document.getElementById('loginId').value;
    const errorDisplay = document.getElementById('loginError');

    if (otp.length >= 4) {
        // إخفاء قسم الـ OTP وإظهار قسم مراجعة البيانات
        document.getElementById('otpSection').classList.add('hidden');
        document.getElementById('reviewDataSection').classList.remove('hidden');

        // جلب البيانات من القاعدة بناءً على الهوية
        const userData = mockDB[id] || mockDB["default"];
        
        // تعبئة الحقول ليقوم المستخدم بالتأكيد أو التعديل
        document.getElementById('editName').value = userData.name;
        document.getElementById('editUniversity').value = userData.uni;
        document.getElementById('editMajor').value = userData.major;
        
        errorDisplay.textContent = "";
    } else {
        errorDisplay.textContent = "يرجى إدخال رمز التحقق بشكل صحيح";
    }
}

// الخطوة 3: التأكيد النهائي وحفظ الجلسة
function confirmAndGo() {
    const finalName = document.getElementById('editName').value;
    const finalUni = document.getElementById('editUniversity').value;
    const finalMajor = document.getElementById('editMajor').value;

    if (finalName.trim() === "") {
        alert("يرجى التأكد من كتابة الاسم");
        return;
    }

    // حفظ البيانات في LocalStorage لتعمل في كل الصفحات
    localStorage.setItem('isLoggedIn', 'true');
    localStorage.setItem('userName', finalName);
    localStorage.setItem('userUniversity', finalUni);
    localStorage.setItem('userMajor', finalMajor);

    // التوجه لصفحة الوظائف
    window.location.href = 'dashboard.html';
}

// دخول الموظفين (تبسيط)
function employeeLogin() {
    const user = document.getElementById('empUser').value;
    const pass = document.getElementById('empPass').value;
    const errorText = document.getElementById('loginError');

    // بيانات الدخول التجريبية
    if (user === "Manqiyah" && pass === "1234") {
        localStorage.setItem('isLoggedIn', 'true');
        localStorage.setItem('userName', "مدير النظام");
        window.location.href = 'employee.html';
    } else {
        document.getElementById('loginError').textContent = "اسم المستخدم أو كلمة المرور غير صحيحة";
    }

}

/* ============================================================
   3. إدارة صفحة الوظائف (البحث، الفلترة، الحماية)
   ============================================================ */

document.addEventListener('DOMContentLoaded', () => {
    const isLoggedIn = localStorage.getItem('isLoggedIn');
    const path = window.location.pathname;

    // أ- حماية الصفحات: منع الدخول لغير المسجلين
    if (!isLoggedIn && path.includes('jobs.html')) {
        window.location.href = 'login.html';
    }
    

    // ب- تحديث الهيدر: عرض اسم المستخدم الذي أكده في خطوة الدخول
    const savedName = localStorage.getItem('userName');
    const welcomeLink = document.getElementById('welcomeUser');
    if (savedName && welcomeLink) {
        welcomeLink.textContent = `أهلاً، ${savedName}`;
    }

    // ج- منطق صفحة التوافق (إذا كان المستخدم فيها)
    const matchBar = document.getElementById('matchBar');
    if (matchBar) {
        runMatchAnalysis();
    }
});

// وظيفة البحث النصي
function searchJobs() {
    const input = document.getElementById('searchInput').value.toLowerCase();
    const jobs = document.querySelectorAll('.job');

    jobs.forEach(job => {
        const title = job.querySelector('h3').textContent.toLowerCase();
        const desc = job.querySelector('p').textContent.toLowerCase();
        
        if (title.includes(input) || desc.includes(input)) {
            job.style.display = 'block';
        } else {
            job.style.display = 'none';
        }
    });
}

// وظيفة الفلترة حسب القطاع
function filterJobs() {
    const filterValue = document.getElementById('jobFilter').value;
    const jobs = document.querySelectorAll('.job');

    jobs.forEach(job => {
        const category = job.getAttribute('data-category');
        if (filterValue === 'all' || category === filterValue) {
            job.style.display = 'block';
        } else {
            job.style.display = 'none';
        }
    });
}

// ==================== السايد بار ====================

function toggleMenu(){

const menu=document.getElementById("sideMenu");

menu.classList.toggle("open");

}


// اغلاق السايدبار عند الضغط خارجها
document.addEventListener("click",function(e){

const menu=document.getElementById("sideMenu");

const btn=document.querySelector(".menu-btn");

if(!menu || !btn) return;

if(!menu.contains(e.target) && !btn.contains(e.target)){

menu.classList.remove("open");

}

});

// تسجيل الخروج ومسح الذاكرة
function logout() {
    localStorage.clear();
    window.location.href = 'login.html';
}

// التقديم وفتح صفحة التوافق
function openPopup(jobTitle) {
    localStorage.setItem('selectedJob', jobTitle);
    window.location.href = 'match.html';
}

/* ============================================================
   4. محاكاة تحليل التوافق (صفحة Match)
   ============================================================ */
function runMatchAnalysis() {
    const percentageLabel = document.getElementById('percentageLabel');
    const matchBar = document.getElementById('matchBar');
    
    // نسبة عشوائية بين 65% و 98% لإعطاء واقعية
    const randomPercent = Math.floor(Math.random() * (98 - 65 + 1)) + 65;

    setTimeout(() => {
        matchBar.style.width = randomPercent + '%';
        percentageLabel.textContent = `نسبة توافق مؤهلاتك مع الوظيفة: ${randomPercent}%`;
    }, 500);
}
function finalApply(){

const job = localStorage.getItem("job") || "الوظيفة";

alert("تم إرسال طلبك للوظيفة: " + job + " بنجاح");

window.location.href = "jobs.html";

}

// بوابة الموظفين


/**
 * نظام إدارة منقية - الجزء الخاص بالموظفين
 * يتضمن: إدارة الوظائف، مراقبة AI، وفحص المتقدمين
 */

// 1. بيانات المتقدمين الوهمية للتحليل
let applicants = [
    { 
        name: "عبدالعزيز الشمري", 
        uni: "جامعة الملك سعود", 
        major: "علوم حاسب", 
        skills: "Java, Spring, SQL", 
        trust: 99, 
        match: 91,
        aiReport: "تم التحقق من الوثائق الرسمية بنجاح. المهارات التقنية تتطابق بنسبة 91% مع احتياج الشركة الحالي." 
    },
    { 
        name: "نورة القحطاني", 
        uni: "جامعة الأميرة نورة", 
        major: "نظم معلومات", 
        skills: "UI/UX, Figma, Adobe XD", 
        trust: 94, 
        match: 85,
        aiReport: "ملف الإنجاز (Portfolio) متميز جداً. نوصي بتحديد موعد مقابلة فنية فوراً." 
    }
];

// 2. بيانات الوظائف (محفوظة في localStorage)
let jobs = JSON.parse(localStorage.getItem('monqiahJobs')) || [
    { title: "مبرمج تطبيقات", company: "حلول رقمية", skills: "Flutter, Firebase", exp: "3 سنوات" },
    { title: "أخصائي أمن سيبراني", company: "تأمين تك", skills: "Pentesting, Linux", exp: "سنتين" }
];

// 3. بيانات خريطة الجامعات والمهارات
const uniSkillsData = [
    { uni: "جامعة الملك سعود", skill: "البرمجة وهندسة البرمجيات" },
    { uni: "جامعة الملك فهد", skill: "الذكاء الاصطناعي والبيانات" },
    { uni: "جامعة الأميرة نورة", skill: "تجربة المستخدم والأمن" }
];

// --- وظائف التحكم بالواجهة ---

function switchTab(tabId, event) {
    document.querySelectorAll('.tab-content').forEach(s => s.classList.add('hidden'));
    document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
    
    document.getElementById(tabId).classList.remove('hidden');
    event.currentTarget.classList.add('active');

    if(tabId === 'screening') renderSidebar();
}

// --- إدارة الوظائف (CRUD) ---

function renderJobs() {
    const tableBody = document.getElementById('jobsTableBody');
    tableBody.innerHTML = jobs.map((j, i) => `
        <tr>
            <td><strong>${j.title}</strong></td>
            <td>${j.company}</td>
            <td><span style="font-size:11px; background:#e2e8f0; padding:3px 8px; border-radius:5px;">${j.skills}</span></td>
            <td>${j.exp}</td>
            <td>
                <button onclick="editJob(${i})" style="color:var(--primary); background:none; border:none; cursor:pointer; font-weight:bold;">تعديل</button>
                <button onclick="deleteJob(${i})" style="color:red; background:none; border:none; cursor:pointer; margin-right:10px;">حذف</button>
            </td>
        </tr>
    `).join('');
    
    document.getElementById('statJobs').textContent = jobs.length;
    document.getElementById('statApps').textContent = applicants.length;
    localStorage.setItem('monqiahJobs', JSON.stringify(jobs));
}

function openJobModal() {
    document.getElementById('modalTitle').textContent = "إضافة وظيفة جديدة";
    document.getElementById('editIndex').value = "-1";
    document.getElementById('jTitle').value = "";
    document.getElementById('jCompany').value = "";
    document.getElementById('jSkills').value = "";
    document.getElementById('jExp').value = "";
    document.getElementById('jobModal').classList.remove('hidden');
}

function editJob(i) {
    const j = jobs[i];
    document.getElementById('modalTitle').textContent = "تعديل بيانات الوظيفة";
    document.getElementById('editIndex').value = i;
    document.getElementById('jTitle').value = j.title;
    document.getElementById('jCompany').value = j.company;
    document.getElementById('jSkills').value = j.skills;
    document.getElementById('jExp').value = j.exp;
    document.getElementById('jobModal').classList.remove('hidden');
}

function saveJob() {
    const i = parseInt(document.getElementById('editIndex').value);
    const updatedJob = {
        title: document.getElementById('jTitle').value,
        company: document.getElementById('jCompany').value,
        skills: document.getElementById('jSkills').value,
        exp: document.getElementById('jExp').value
    };

    if(i === -1) jobs.push(updatedJob); else jobs[i] = updatedJob;
    
    renderJobs();
    closeJobModal();
}

function deleteJob(i) {
    if(confirm("هل أنت متأكد من حذف هذه الوظيفة؟")) {
        jobs.splice(i, 1);
        renderJobs();
    }
}

function closeJobModal() { document.getElementById('jobModal').classList.add('hidden'); }

// --- نظام فحص المتقدمين (Screening) ---

function renderSidebar() {
    const sidebar = document.getElementById('applicantSidebar');
    sidebar.innerHTML = applicants.map((app, i) => `
        <div class="app-item" onclick="viewApplicant(${i})">
            <div style="display:flex; justify-content:space-between;">
                <strong>${app.name}</strong>
                <span style="font-size:11px; color:#059669;">موثوقية ${app.trust}%</span>
            </div>
            <small style="color:#64748b">${app.uni}</small>
        </div>
    `).join('');
}

function viewApplicant(i) {
    const app = applicants[i];
    document.querySelectorAll('.app-item').forEach((el, index) => el.classList.toggle('active', index === i));
    
    document.getElementById('applicantDetails').innerHTML = `
        <div style="display:flex; justify-content:space-between; align-items:center;">
            <h2>${app.name}</h2>
            <div style="background:#f0fdf4; color:#166534; padding:8px 15px; border-radius:10px; font-weight:bold;">مطابقة AI: ${app.match}%</div>
        </div>
        <p><strong>التخصص:</strong> ${app.major}</p>
        <p><strong>المهارات:</strong> ${app.skills}</p>
        <div style="background:#fdfaff; border:1px dashed #7c3aed; padding:20px; border-radius:12px; margin-top:20px;">
            <h4 style="color:#7c3aed; margin:0 0 10px 0;">🤖 تقرير تحليل منقية الذكي</h4>
            <p style="font-size:14px; line-height:1.6;">${app.aiReport}</p>
        </div>
        <div style="margin-top:30px; display:flex; gap:10px;">
            <button class="btn btn-save">قبول المتقدم</button>
            <button class="btn btn-cancel" style="background:#ef4444;">رفض</button>
        </div>
    `;
}

// --- تعبئة بيانات مراقبة AI ---

function initAIMonitor() {
    const list = document.getElementById('uniSkillsMap');
    list.innerHTML = uniSkillsData.map(u => `
        <div style="display:flex; justify-content:space-between; padding:10px 0; border-bottom:1px solid #eee;">
            <span>${u.uni}</span>
            <span style="font-weight:bold; color:var(--primary);">${u.skill}</span>
        </div>
    `).join('');
    
    document.getElementById('companyReports').innerHTML = `
        <ul style="font-size:13px; color:#64748b; padding-right:15px;">
            <li>شركة أرامكو: تم تحليل 150 ملف - جودة المطابقة 92%</li>
            <li>نيوم: تم فحص 40 ملف - جودة المطابقة 88%</li>
        </ul>
    `;
}

function logout() { localStorage.clear(); window.location.href = 'login.html'; }

// التشغيل عند التحميل
document.addEventListener('DOMContentLoaded', () => {
    renderJobs();
    initAIMonitor();
});